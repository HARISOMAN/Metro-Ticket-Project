import pandas as pd
import numpy as np
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def parse_volume(x):
    if pd.isna(x):
        return np.nan
    s = str(x).replace(',', '').strip()
    if s.endswith('M'):
        return float(s[:-1]) * 1e6
    if s.endswith('K'):
        return float(s[:-1]) * 1e3
    if s.endswith('B'):
        return float(s[:-1]) * 1e9
    try:
        return float(s)
    except:
        return np.nan

def parse_change_pct(x):
    if pd.isna(x): return np.nan
    s = str(x).strip().replace('%','')
    try:
        return float(s)
    except:
        return np.nan

def load_raw(path: str):
    df = pd.read_csv(path)
    return df

def clean_dataframe(df: pd.DataFrame):
    df = df.copy()
    df = df.rename(columns=lambda c: c.strip())
    if 'Vol.' in df.columns:
        df = df.rename(columns={'Vol.': 'Volume'})
    if 'Change %' in df.columns:
        df = df.rename(columns={'Change %': 'Change_pct'})
    if 'Date' in df.columns:
        df['Date'] = pd.to_datetime(df['Date'], dayfirst=True, errors='coerce')
    for col in ['Price','Open','High','Low']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    if 'Volume' in df.columns:
        df['Volume'] = df['Volume'].apply(parse_volume)
    if 'Change_pct' in df.columns:
        df['Change_pct'] = df['Change_pct'].apply(parse_change_pct)
    df = df.drop_duplicates()
    if 'Date' in df.columns:
        df = df.sort_values('Date').reset_index(drop=True)
    return df

def load_and_clean_all(file_paths, output_path=None):
    dfs = []
    for i, p in enumerate(file_paths, start=1):
        df = load_raw(p)
        df['Source'] = f"dataset{i}"
        df_clean = clean_dataframe(df)
        dfs.append(df_clean)
    combined = pd.concat(dfs, ignore_index=True)
    if 'Date' in combined.columns:
        combined = combined.sort_values(['Date','Source']).reset_index(drop=True)
    if output_path:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        combined.to_csv(output_path, index=False)
    return combined
