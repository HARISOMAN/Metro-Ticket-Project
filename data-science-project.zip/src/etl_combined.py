from pathlib import Path
from src.data_preprocessing import load_and_clean_all

ROOT = Path(__file__).resolve().parents[1]

def main():
    file1 = ROOT / "data" / "raw" / "combined_data.csv"
    out = ROOT / "data" / "processed" / "cleaned_data.csv"
    combined = load_and_clean_all([file1], output_path=out)
    print("Combined shape:", combined.shape)

if __name__ == "__main__":
    main()
